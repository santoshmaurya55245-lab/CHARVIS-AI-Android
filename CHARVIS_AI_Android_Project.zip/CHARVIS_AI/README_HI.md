# CHARVIS AI — Android Kotlin starter project

इस प्रोजेक्ट में Native Kotlin + Jetpack Compose UI, Gemini chat, Hindi speech-to-text, Android Text-to-Speech reply, Android Keystore encrypted API-key storage, Settings और YouTube खोलने का shortcut है।

## Build से पहले
- JDK 17 और Android SDK Platform 35 चाहिए।
- Gemini API key Google AI Studio से लें और ऐप की Settings में डालें।
- API key को source code में hard-code न करें।
- Voice recognition Android speech recognition service पर निर्भर है।
- YouTube बटन YouTube app या browser खोलता है; background playback/control नहीं करता।
- Always-on wake word, WhatsApp/SMS, calls और advanced phone automation इस starter version में शामिल नहीं हैं।

## Android Studio
1. Android Studio में `CHARVIS_AI` folder Open करें।
2. Gradle Sync पूरा होने दें।
3. JDK 17 और Android SDK 35 उपलब्ध रखें।
4. Build > Build APK(s) चुनें।
5. APK: `app/build/outputs/apk/debug/app-debug.apk`

## Gradle command (SDK और Gradle पहले से configured हों)
Project root में चलाएँ:
```bash
gradle :app:assembleDebug
```

**ध्यान दें:** Kotlin code को shell prompt में paste नहीं करना है। Kotlin source `.kt` files में रहता है और Gradle project को build करता है।

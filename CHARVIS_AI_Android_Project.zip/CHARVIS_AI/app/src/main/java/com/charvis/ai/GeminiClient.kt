package com.charvis.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiClient {
    private val http = OkHttpClient.Builder().callTimeout(60, TimeUnit.SECONDS).build()

    suspend fun ask(apiKey: String, prompt: String, model: String): String = withContext(Dispatchers.IO) {
        require(apiKey.isNotBlank()) { "पहले Settings में Gemini API key डालें।" }
        val persona = "You are CHARVIS, a warm, intelligent, caring female personal AI assistant. " +
            "Reply naturally in Hindi or English matching the user. Be honest, clear and practical. " +
            "You are an AI; never claim to perform actions you did not perform."
        val parts = JSONArray().put(JSONObject().put("text", "$persona\n\nUser: $prompt"))
        val body = JSONObject().put("contents", JSONArray().put(JSONObject()
            .put("role", "user").put("parts", parts)))
            .put("generationConfig", JSONObject().put("temperature", 0.7).put("maxOutputTokens", 2048))
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
        val request = Request.Builder().url(url)
            .post(body.toString().toRequestBody("application/json; charset=utf-8".toMediaType())).build()
        http.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val message = try { JSONObject(raw).optJSONObject("error")?.optString("message") }
                    catch (_: Exception) { null }
                throw IllegalStateException(message?.takeIf { it.isNotBlank() } ?: "Gemini request failed (${response.code})")
            }
            JSONObject(raw).optJSONArray("candidates")?.optJSONObject(0)
                ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)
                ?.optString("text")?.takeIf { it.isNotBlank() }
                ?: "मुझे इस बार जवाब नहीं मिला। कृपया दोबारा कोशिश करें।"
        }
    }
}

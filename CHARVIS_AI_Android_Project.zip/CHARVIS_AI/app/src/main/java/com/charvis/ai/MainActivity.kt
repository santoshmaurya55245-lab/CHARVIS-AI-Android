package com.charvis.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch
import java.util.Locale

data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { result ->
            if (result == TextToSpeech.SUCCESS) tts?.language = Locale("hi", "IN")
        }
        setContent { CharvisApp { text -> tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "charvis_reply") } }
    }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CharvisApp(onSpeak: (String) -> Unit) {
    val context = LocalContext.current
    val secure = remember { SecurePrefs(context) }
    val gemini = remember { GeminiClient() }
    val scope = rememberCoroutineScope()
    var apiKey by remember { mutableStateOf(secure.getApiKey()) }
    var model by remember { mutableStateOf("gemini-2.0-flash") }
    var showSettings by remember { mutableStateOf(apiKey.isBlank()) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Ready • Add Gemini API key in Settings") }
    val messages = remember { mutableStateListOf(ChatMessage("नमस्ते! मैं CHARVIS हूँ। बताइए, आज मैं आपकी क्या मदद करूँ?", false)) }

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        input = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "CHARVIS को बोलकर बताइए")
            }
            try { speechLauncher.launch(intent) } catch (_: Exception) { status = "Speech service उपलब्ध नहीं है।" }
        } else status = "Microphone permission नहीं मिली।"
    }

    fun sendMessage() {
        val prompt = input.trim()
        if (prompt.isEmpty() || busy) return
        input = ""
        messages.add(ChatMessage(prompt, true))
        busy = true
        scope.launch {
            try {
                val answer = gemini.ask(apiKey, prompt, model)
                messages.add(ChatMessage(answer, false))
                onSpeak(answer)
                status = "Connected • Gemini"
            } catch (e: Exception) {
                messages.add(ChatMessage("माफ़ कीजिए: ${e.message ?: "कुछ गड़बड़ हुई"}", false))
                status = "API / network error"
            } finally { busy = false }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF63D8FF), secondary = Color(0xFFB78CFF),
        background = Color(0xFF070B18), surface = Color(0xFF111A2D)
    )) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
            listOf(Color(0xFF080D20), Color(0xFF15102B))))) {
            Column(Modifier.fillMaxSize().padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.weight(1f)) {
                        Text("CHARVIS AI", color = Color(0xFF75DEFF), fontSize = 25.sp)
                        Text("MY PERSONAL FEMALE JARVIS", color = Color.LightGray, fontSize = 10.sp)
                    }
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color(0xFF75DEFF))
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(status, color = Color(0xFF9BAAC8), fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(messages) { msg ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement =
                            if (msg.fromUser) Arrangement.End else Arrangement.Start) {
                            Surface(color = if (msg.fromUser) Color(0xFF263B67) else Color(0xFF17243A),
                                shape = RoundedCornerShape(16.dp), modifier = Modifier.widthIn(max = 310.dp)) {
                                Text(msg.text, color = Color.White, modifier = Modifier.padding(13.dp))
                            }
                        }
                    }
                    if (busy) item { CircularProgressIndicator(color = Color(0xFF75DEFF), modifier = Modifier.size(24.dp)) }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(value = input, onValueChange = { input = it },
                        modifier = Modifier.weight(1f), placeholder = { Text("CHARVIS से बात करें…") },
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { sendMessage() }), maxLines = 4)
                    IconButton(onClick = {
                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                            PackageManager.PERMISSION_GRANTED) {
                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                            }
                            try { speechLauncher.launch(intent) } catch (_: Exception) { status = "Speech service unavailable" }
                        } else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }) { Icon(Icons.Default.Mic, contentDescription = "Speak", tint = Color(0xFF75DEFF)) }
                    IconButton(onClick = { sendMessage() }, enabled = !busy) {
                        Icon(Icons.Default.Send, contentDescription = "Send", tint = Color(0xFF75DEFF))
                    }
                }
                TextButton(onClick = {
                    try { context.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.youtube.com"))) }
                    catch (_: Exception) { status = "YouTube नहीं खुल सका" }
                }) { Text("Open YouTube", color = Color(0xFFBCA5FF)) }
            }
            if (showSettings) {
                AlertDialog(onDismissRequest = { showSettings = false },
                    title = { Text("CHARVIS Settings") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Gemini API key डालें। यह Android Keystore की मदद से encrypt होकर सेव होगी।", fontSize = 13.sp)
                            OutlinedTextField(value = apiKey, onValueChange = { apiKey = it },
                                label = { Text("Gemini API Key") },
                                visualTransformation = PasswordVisualTransformation(), singleLine = true)
                            OutlinedTextField(value = model, onValueChange = { model = it },
                                label = { Text("Gemini model") }, singleLine = true)
                            Text("अपनी API key निजी रखें। Google AI Studio से key प्राप्त करें।",
                                fontSize = 11.sp, color = Color.Gray)
                        }
                    },
                    confirmButton = { TextButton(onClick = {
                        secure.saveApiKey(apiKey.trim()); showSettings = false
                        status = if (apiKey.isBlank()) "API key missing" else "API key saved on this device"
                    }) { Text("Save") } },
                    dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Cancel") } }
                )
            }
        }
    }
}
